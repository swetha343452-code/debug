"""
Resource Scheduler Module
Manages resource allocation with priority scheduling.
"""

import heapq
import threading
import time


class Resource:
    """Represents a schedulable resource."""
    
    def __init__(self, name, capacity=1):
        self.name = name
        self.capacity = capacity
        self.current_usage = 0
        self._lock = threading.Lock()
    
    def is_available(self):
        """Check if resource has available capacity."""
        return self.current_usage < self.capacity
    
    def acquire(self):
        """Acquire one unit of this resource."""
        with self._lock:
            if self.current_usage >= self.capacity:
                raise ValueError(f"Resource {self.name} is at capacity")
            self.current_usage += 1
            return True
    
    def release(self):
        """Release one unit of this resource."""
        with self._lock:
            if self.current_usage <= 0:
                raise ValueError(f"Resource {self.name} is not in use")
            self.current_usage -= 1
            return True


class Task:
    """Represents a task with priority."""
    
    def __init__(self, name, priority, resource_name):
        self.name = name
        self.priority = priority  # Lower number = higher priority
        self.resource_name = resource_name
        self.completed = False
        self.started = False
        self.wait_count = 0  # Track how many times task was skipped
    
    def __lt__(self, other):
        """
        Compare tasks for priority queue.

        FIX 8: Corrected priority comparison — lower number = higher priority.
        """
        # FIX 8: Use effective_priority for aging-aware comparison
        return self.effective_priority() < other.effective_priority()
    
    def effective_priority(self):
        """Effective priority with aging to prevent starvation."""
        return self.priority - (self.wait_count * 2)
    
    def __eq__(self, other):
        return self.effective_priority() == other.effective_priority()


class ResourceScheduler:
    """Schedules tasks on resources with priority."""
    
    def __init__(self):
        self._resources = {}      # name -> Resource
        self._task_queue = []     # heap of tasks
        self._completed = []      # completed tasks
        self._lock = threading.Lock()
        self._starvation_threshold = 5  # Max times a task can be skipped
    
    def add_resource(self, name, capacity=1):
        """Add a resource to the scheduler."""
        self._resources[name] = Resource(name, capacity)
    
    def submit_task(self, task):
        """
        Submit a task to the scheduler.

        FIX 9: Removed silent drop for tasks with priority >= 50.
        All tasks are now accepted regardless of priority number.
        """
        # FIX 9: No longer drop tasks with priority >= 50
        with self._lock:
            heapq.heappush(self._task_queue, task)
    
    def execute_next(self):
        """
        Execute the next highest-priority task.

        FIX 10: Starvation prevention via wait_count aging.
        FIX 12: Resource is released after task completes.
        """
        with self._lock:
            if not self._task_queue:
                return None
            
            # Re-heapify to account for aging changes
            heapq.heapify(self._task_queue)
            task = heapq.heappop(self._task_queue)
        
        resource_name = task.resource_name
        if resource_name not in self._resources:
            raise ValueError(f"Resource {resource_name} not found")
        
        resource = self._resources[resource_name]
        
        if not resource.is_available():
            task.wait_count += 1
            with self._lock:
                heapq.heappush(self._task_queue, task)
            return None
        
        # Execute task
        resource.acquire()
        task.started = True
        task.completed = True
        resource.release()
        
        with self._lock:
            self._completed.append(task)
        
        return task
    
    def execute_all(self):
        """Execute all tasks in priority order."""
        results = []
        max_iterations = len(self._task_queue) * 10  # Prevent infinite loop
        iterations = 0
        
        while self._task_queue and iterations < max_iterations:
            result = self.execute_next()
            if result:
                results.append(result)
            iterations += 1
        
        return results
    
    def get_completed_tasks(self):
        """Return list of completed tasks."""
        return list(self._completed)
    
    def get_pending_tasks(self):
        """Return list of pending tasks."""
        with self._lock:
            return list(self._task_queue)
    
    def get_resource_status(self):
        """Return status of all resources. FIX 13: uses 'capacity' key."""
        return {
            name: {
                "capacity": r.capacity,
                "usage": r.current_usage,
                "available": r.is_available()
            }
            for name, r in self._resources.items()
        }
    
    def reset(self):
        """Reset scheduler state."""
        self._resources.clear()
        self._task_queue.clear()
        self._completed.clear()
