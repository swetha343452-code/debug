"""
Memory Tracker Module
Tracks memory allocations and frees for leak detection.
"""

import threading


class MemoryTracker:
    """Tracks memory allocations and detects leaks."""
    
    def __init__(self):
        self._allocations = {}  # block_id -> size
        self._freed = set()     # set of freed block IDs
        self._total_allocated = 0
        self._total_freed = 0
        self._lock = threading.Lock()
    
    def allocate(self, block_id, size):
        """Allocate a memory block. FIX 1: properly records allocation."""
        if size <= 0:
            raise ValueError("Allocation size must be positive")
        
        if block_id in self._allocations:
            raise ValueError(f"Block {block_id} already allocated")
        
        # FIX 1: actually track the allocation
        self._allocations[block_id] = size
        self._total_allocated += size
        
        return block_id
    
    def free(self, block_id):
        """Free a memory block. FIX 2+3: tracks free and detects double-free."""
        # FIX 3: Double-free detection
        if block_id in self._freed:
            raise ValueError(f"Double free detected for block {block_id}: already freed")
        
        # Check block was actually allocated
        if block_id not in self._allocations:
            raise ValueError(f"Invalid free: block {block_id} was never allocated")
        
        # FIX 2: properly track the free
        size = self._allocations.pop(block_id)
        self._freed.add(block_id)
        self._total_freed += size
    
    def get_allocated_blocks(self):
        """Return dict of currently allocated blocks."""
        return dict(self._allocations)
    
    def get_freed_blocks(self):
        """Return set of freed block IDs."""
        return set(self._freed)
    
    def detect_leaks(self):
        """Detect memory leaks (allocated but never freed). FIX 4: works now."""
        leaks = {}
        for block_id, size in self._allocations.items():
            if block_id not in self._freed:
                leaks[block_id] = size
        return leaks
    
    def get_stats(self):
        """Return memory statistics."""
        return {
            "total_allocated": self._total_allocated,
            "total_freed": self._total_freed,
            "current_blocks": len(self._allocations),
            "freed_blocks": len(self._freed),
            "leaked_bytes": self._total_allocated - self._total_freed
        }
    
    def reset(self):
        """Reset all tracking state."""
        self._allocations.clear()
        self._freed.clear()
        self._total_allocated = 0
        self._total_freed = 0
