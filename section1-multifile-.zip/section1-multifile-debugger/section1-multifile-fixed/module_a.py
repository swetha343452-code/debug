"""
User management module
"""

# FIX 9: Import the function, not the raw variable
from state import increment_count


users = []


def add_user():
    """Add a new user"""
    # FIX: Call increment_count() to properly update shared state
    increment_count()

    user_id = len(users) + 1
    users.append(f"User_{user_id}")

    # FIX 8+10: Use local import inside function to break circular dependency
    from module_b import log_analytics
    log_analytics("user_added", user_id)

    return user_id


def get_user_list():
    """Get list of all users"""
    return users


def remove_user(user_id):
    """Remove a user"""
    if user_id <= len(users):
        users.pop(user_id - 1)
