"""
Section 4: Logical Tracing - Code Detective Challenge

All 10 logic bugs fixed + bonus Fibonacci bug.
"""


# ============================================================
# FUNCTION 1: E-Commerce Discount Calculator
# FIX 1: Changed > to >= for boundary values
# ============================================================

def calculate_discount(order_amount):
    """Calculate discount based on order amount."""
    if order_amount >= 100:        # FIX: >= instead of >
        return 0.10
    elif order_amount >= 50:       # FIX: >= instead of >
        return 0.05
    else:
        return 0.0


# ============================================================
# FUNCTION 2: User Authentication
# FIX 2: Changed 'or' to 'and' — both fields required
# ============================================================

def authenticate_user(username, password):
    """Authenticate a user with username and password."""
    if username and password:       # FIX: 'and' not 'or'
        return True
    return False


# ============================================================
# FUNCTION 3: Majority Element Finder
# FIX 3a: Empty list returns None instead of raising
# FIX 3b: count == 0 (not count == 1) resets candidate
# FIX 3c: Verifies candidate actually has majority count
# ============================================================

def find_majority_element(nums):
    """Find the majority element (appears > n/2 times)."""
    if not nums:
        return None  # FIX 3a: return None, not raise

    candidate = nums[0]
    count = 1

    for i in range(1, len(nums)):
        if count == 0:              # FIX 3b: reset when count hits 0
            candidate = nums[i]
            count = 1
        elif nums[i] == candidate:
            count += 1
        else:
            count -= 1

    # FIX 3c: Verify candidate is actually a majority element
    if nums.count(candidate) > len(nums) // 2:
        return candidate
    return None


# ============================================================
# FUNCTION 4: Compound Interest Calculator
# FIX 4: Fixed operator precedence — ** (compounds_per_year * years)
# ============================================================

def calculate_compound_interest(principal, rate, compounds_per_year, years):
    """Calculate compound interest. A = P * (1 + r/n)^(n*t)"""
    # FIX 4: added parentheses so exponent is (compounds_per_year * years)
    amount = principal * (1 + rate / compounds_per_year) ** (compounds_per_year * years)
    return round(amount, 2)


# ============================================================
# FUNCTION 5: Merge Two Sorted Arrays
# FIX 5: extend from index i / j (not i+1 / j+1)
# ============================================================

def merge_sorted_arrays(arr1, arr2):
    """Merge two sorted arrays into one sorted array."""
    result = []
    i, j = 0, 0

    while i < len(arr1) and j < len(arr2):
        if arr1[i] <= arr2[j]:
            result.append(arr1[i])
            i += 1
        else:
            result.append(arr2[j])
            j += 1

    # FIX 5: slice from i and j (not i+1, j+1)
    result.extend(arr1[i:])
    result.extend(arr2[j:])

    return result


# ============================================================
# FUNCTION 6: Password Validator
# FIX 6: Changed 'or' to 'and' — all conditions required
# ============================================================

def validate_password(password):
    """Validate password meets security requirements."""
    has_length = len(password) >= 8
    has_upper = any(c.isupper() for c in password)
    has_digit = any(c.isdigit() for c in password)

    # FIX 6: 'and' not 'or'
    return has_length and has_upper and has_digit



def binary_search(sorted_list, target):
    """Perform binary search on a sorted list."""
    left, right = 0, len(sorted_list) - 1

    while left <= right:           
        mid = (left + right) // 2
        if sorted_list[mid] == target:
            return mid
        elif sorted_list[mid] < target:
            left = mid + 1
        else:
            right = mid - 1

    return -1        


class ListNode:
    """Simple linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def detect_cycle(head):
    """Detect if a linked list has a cycle."""
    if not head or not head.next:
        return False   

    slow = head
    fast = head

    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow == fast:
            return True          

    return False   


def calculate_tax_bracket(income):
    """Calculate progressive tax based on income brackets."""
    if income <= 0:            
        return 0.0

    tax = 0.0                   

    if income > 85000:
        tax += (income - 85000) * 0.40
        income = 85000
    if income > 40000:             
        tax += (income - 40000) * 0.30
        income = 40000
    if income > 10000:             
        tax += (income - 10000) * 0.20
        income = 10000
    tax += income * 0.10

    return round(tax, 2)


def graph_shortest_path(graph, start, end):
    """Find shortest path in an unweighted graph using BFS."""
    if start == end:
        return [start]   

    if start not in graph:
        return []

    from collections import deque

    queue = deque()
    queue.append([start])
    visited = set()

    while queue:
        path = queue.popleft()
        node = path[-1]

        if node in visited:
            continue
        visited.add(node)

        for neighbor in graph.get(node, []):
            new_path = list(path)   
            new_path.append(neighbor)
            if neighbor == end:
                return new_path
            queue.append(new_path)

    return []   


def calculate_fibonacci(n):
    """Calculate the nth Fibonacci number."""
    if n < 0:   
        raise ValueError("n must be non-negative")

    if n == 0:  
        return 0

    if n == 1:
        return 1

    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b
